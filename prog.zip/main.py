import sys
sys.path.insert(1, './2D/')


from interface import Vapp

Vapp.run()